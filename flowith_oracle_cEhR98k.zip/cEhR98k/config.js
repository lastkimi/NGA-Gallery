export const CONFIG = {
    MUSEUM_NAME: "National Gallery of Art",
    ACCENT_COLOR: "#73216D",
    OPENROUTER_API_KEY: "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",
    MAX_ITEMS_PER_PAGE: 12,
    IMAGE_FALLBACK: "https://www.nga.gov/content/ngaweb/en/research/online-editions/american-paintings-18th-century/the-collection/jcr:content/par/image.img.jpg/1406649600000.jpg"
};
